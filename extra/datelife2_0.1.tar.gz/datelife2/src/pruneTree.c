# define USE_RINTERNALS

#include <Rmath.h>
#include <math.h>
#include <R.h> 

#include <Rinternals.h>


void prune_tree(int *edge1, int *edge2, int *n, int *nTips, int *include, int *nodes)
{
    int i, a, d;
    for(i =*n-1L; i>-1L; i--){
        a = edge1[i] - 1L;
        d = edge2[i] - 1L; 
        nodes[a] += nodes[d];      
    }  
    for(i =*n-1L; i>-1L; i--){
        d = edge2[i] - 1;
        if(nodes[d]==*nTips)break; // stop early if all tips included  
        if(nodes[d]>0){
            include[i] = 1L;    
        } 
    }
}


